package com.futbolhub.creatorplan

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF070B14)
private val Card = Color(0xFF111827)
private val Blue = Color(0xFF2563EB)
private val Green = Color(0xFF22C55E)
private val Red = Color(0xFFEF4444)
private val Text = Color(0xFFF8FAFC)
private val Muted = Color(0xFF94A3B8)

data class Match(val home:String,val away:String,val score:String,val status:String)
data class News(val title:String,val category:String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var tab by remember { mutableStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Card, primary = Blue,
        onBackground = Text, onSurface = Text
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = { BottomBar(tab) { tab = it } }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when(tab) {
                    0 -> Home()
                    1 -> Matches()
                    2 -> Creator()
                    3 -> FootballAI()
                    else -> Profile()
                }
            }
        }
    }
}

@Composable
fun BottomBar(tab:Int,onTab:(Int)->Unit) {
    NavigationBar(containerColor = Color(0xFF0B1220)) {
        listOf("Inicio","Partidos","Crear","Fútbol AI","Perfil").forEachIndexed { i,label ->
            NavigationBarItem(
                selected = tab==i, onClick={onTab(i)},
                icon={Text(listOf("⌂","⚽","✦","✧","●")[i], fontSize=18.sp)},
                label={Text(label,fontSize=11.sp)}
            )
        }
    }
}

@Composable
fun Header(title:String, subtitle:String?=null) {
    Column(Modifier.fillMaxWidth().padding(18.dp)) {
        Text(title,fontSize=28.sp,fontWeight=FontWeight.Bold,color=Text)
        subtitle?.let { Text(it,color=Muted,fontSize=13.sp,modifier=Modifier.padding(top=4.dp)) }
    }
}

@Composable
fun Section(title:String, action:String?=null) {
    Row(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=8.dp),horizontalArrangement=Arrangement.SpaceBetween) {
        Text(title,fontSize=18.sp,fontWeight=FontWeight.Bold)
        action?.let { Text(it,color=Blue,fontSize=13.sp) }
    }
}

@Composable
fun MatchCard(m:Match) {
    Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=6.dp),shape=RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(m.home,fontWeight=FontWeight.SemiBold)
                Text(m.away,color=Muted,modifier=Modifier.padding(top=6.dp))
            }
            Column(horizontalAlignment=Alignment.End) {
                Text(m.score,fontSize=19.sp,fontWeight=FontWeight.Bold)
                Text(m.status,color=if(m.status=="EN VIVO") Red else Muted,fontSize=11.sp)
            }
        }
    }
}

val demoMatches = listOf(
    Match("Real Madrid","Barcelona","2 - 1","EN VIVO"),
    Match("Arsenal","Chelsea","—","20:00"),
    Match("Manchester City","Liverpool","—","21:00"),
    Match("Inter","Juventus","—","Mañana")
)

@Composable
fun Home() {
    LazyColumn {
        item { Header("FÚTBOL HUB","Tu centro de fútbol + creación de contenido") }
        item {
            Card(Modifier.fillMaxWidth().padding(horizontal=18.dp),shape=RoundedCornerShape(20.dp),
                colors=CardDefaults.cardColors(containerColor=Color(0xFF172554))) {
                Column(Modifier.padding(18.dp)) {
                    Text("TU FÚTBOL",color=Muted,fontSize=12.sp)
                    Text("Todo lo que necesitas en una sola app",fontSize=22.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=5.dp))
                    Text("Partidos • Noticias • Datos • IA • Contenido",color=Color(0xFFBFDBFE),modifier=Modifier.padding(top=8.dp))
                }
            }
        }
        item { Section("En vivo","Ver todos") }
        item { MatchCard(demoMatches[0]) }
        item { Section("Próximos partidos") }
        items(demoMatches.drop(1)) { MatchCard(it) }
        item { Section("Noticias") }
        items(listOf(
            News("El mercado de fichajes entra en una semana decisiva","FICHAJES"),
            News("Análisis: cómo controlar el ritmo del partido","ANÁLISIS"),
            News("Las claves tácticas de la jornada","TÁCTICA")
        )) { NewsCard(it) }
    }
}

@Composable
fun NewsCard(n:News) {
    Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=5.dp),shape=RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(15.dp)) {
            Text(n.category,color=Green,fontSize=11.sp,fontWeight=FontWeight.Bold)
            Text(n.title,fontSize=16.sp,fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(top=5.dp))
            Text("Fuente demo • Información de demostración",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=7.dp))
        }
    }
}

@Composable
fun Matches() {
    LazyColumn {
        item { Header("Partidos","Resultados, calendario y seguimiento") }
        item { Section("EN VIVO") }
        item { MatchCard(demoMatches[0]) }
        item { Section("HOY") }
        items(demoMatches.drop(1)) { MatchCard(it) }
        item { Section("Competiciones") }
        items(listOf("LaLiga","Premier League","Champions League","Liga 1 Perú","Serie A","Bundesliga")) {
            SimpleCard(it,"Clasificación • Partidos • Equipos • Estadísticas")
        }
    }
}

@Composable
fun SimpleCard(title:String,sub:String) {
    Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=5.dp),shape=RoundedCornerShape(14.dp)) {
        Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
            Text("⚽",fontSize=22.sp,modifier=Modifier.padding(end=12.dp))
            Column {
                Text(title,fontWeight=FontWeight.Bold)
                Text(sub,color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=3.dp))
            }
        }
    }
}

@Composable
fun Creator() {
    var idea by remember { mutableStateOf("") }
    var generated by remember { mutableStateOf(false) }
    LazyColumn {
        item { Header("CREATOR PLAN","Convierte fútbol en contenido") }
        item {
            Card(Modifier.fillMaxWidth().padding(18.dp),shape=RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Generador rápido",fontSize=19.sp,fontWeight=FontWeight.Bold)
                    Text("Escribe un tema y crea una estructura de contenido.",color=Muted,fontSize=13.sp,modifier=Modifier.padding(top=4.dp))
                    OutlinedTextField(
                        value=idea,onValueChange={idea=it},
                        placeholder={Text("Ej. Zubimendi y su encaje...")},
                        modifier=Modifier.fillMaxWidth().padding(top=12.dp)
                    )
                    Button(onClick={generated=true},modifier=Modifier.fillMaxWidth().padding(top=10.dp)) {
                        Text("Generar contenido")
                    }
                    if(generated) {
                        Text("HOOK",color=Green,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=16.dp))
                        Text("“Hay un detalle que cambia por completo este análisis…”")
                        Text("ESTRUCTURA",color=Green,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp))
                        Text("Contexto → 3 datos clave → análisis → conclusión → CTA")
                        Text("CTA",color=Green,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp))
                        Text("“¿Tú qué opinas? Déjalo en comentarios.”")
                    }
                }
            }
        }
        item { Section("Herramientas") }
        items(listOf(
            "Ideas de contenido","Calendario editorial","Guiones","Copy + hashtags",
            "Gestor de producción","Analítica","Contenido publicado"
        )) { SimpleCard(it,"Módulo Creator Plan") }
    }
}

@Composable
fun FootballAI() {
    var q by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    LazyColumn {
        item { Header("FÚTBOL AI","Asistente futbolístico") }
        item {
            Card(Modifier.fillMaxWidth().padding(18.dp),shape=RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Pregunta sobre fútbol",fontWeight=FontWeight.Bold,fontSize=18.sp)
                    OutlinedTextField(value=q,onValueChange={q=it},placeholder={Text("Ej. Compara dos mediocampistas")},modifier=Modifier.fillMaxWidth().padding(top=10.dp))
                    Button(onClick={answer="Modo demo: para respuestas con datos actuales conecta un proveedor de datos deportivos y un modelo de IA."},modifier=Modifier.fillMaxWidth().padding(top=10.dp)) { Text("Analizar") }
                    if(answer.isNotBlank()) Text(answer,color=Muted,modifier=Modifier.padding(top=14.dp))
                }
            }
        }
        item { Section("Análisis disponibles") }
        items(listOf("Comparador de jugadores","Análisis de partidos","Forma reciente","Análisis táctico","Predicciones estadísticas")) {
            SimpleCard(it,"Preparado para integración de datos")
        }
    }
}

@Composable
fun Profile() {
    LazyColumn {
        item { Header("Perfil","Personaliza tu experiencia") }
        item { SimpleCard("Mis equipos","Real Madrid • Arsenal") }
        item { SimpleCard("Mis jugadores","Favoritos") }
        item { SimpleCard("Mis competiciones","LaLiga • Champions") }
        item { SimpleCard("Notificaciones","Goles • Partidos • Fichajes") }
        item { SimpleCard("Tema","Oscuro premium") }
        item { SimpleCard("Cuenta","Modo demostración") }
    }
}
