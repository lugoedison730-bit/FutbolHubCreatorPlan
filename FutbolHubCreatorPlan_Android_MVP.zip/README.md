# Fútbol Hub + Creator Plan

MVP Android de una aplicación unificada de fútbol y planificación de contenido.

## Qué incluye
- Dashboard integrado.
- Partidos, resultados y próximos partidos con datos demo.
- Equipos, jugadores, competiciones y clasificaciones demo.
- Noticias y mercado de fichajes demo.
- Fútbol AI con respuestas locales de demostración.
- Favoritos.
- Creator Plan: ideas, calendario, generador de guiones, producción y analítica demo.
- Tema oscuro premium.
- Arquitectura preparada para conectar APIs, Firebase e IA reales.

## Requisitos
- Android Studio Hedgehog o superior.
- JDK 17.
- Android SDK 35.
- Kotlin/Gradle.

## Abrir
1. Descomprime el proyecto.
2. Abre la carpeta en Android Studio.
3. Espera a que Gradle sincronice.
4. Ejecuta en un dispositivo Android o emulador.
5. Para APK: Build > Build APK(s).

## Nota
Los datos deportivos son de demostración. No se presentan como datos en tiempo real.
